# Imports

from random import *
from math import *
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import numpy as np
import networkx as nx
import copy
import os
import glob
import csv

# Definitions of the variables

IND = 0 # For data file name

# Elastic structure

l0 = 1.0
L = 21
alpha = 1.0 # Mechanical tension

def nCouronne(L):
    
    N = 1 # Central nodes
    for l in range(L):
        N = N + 6*l # Ring k contains 6k nodes

    return(N)

N = nCouronne(L)
print('Total number of nodes = '+str(N))

Nmat = nCouronne(L-1)
print('Number of free nodes = '+str(Nmat))

# Simulation parameters

dt = 0.001
num = 1000

PiBar = 2.0 # Elasto-active coupling

# Definition of the triangular lattice graph

G = nx.Graph(directed=False)
G.add_node((0,0))
pos = {}
pos[(0,0)] = (0,0)

for n in range(L):
    
    list = copy.deepcopy(G.nodes())
    
    for (q,r) in list: 
        G.add_edge((q,r),(q,r-1))
        pos[(q,r-1)] = (pos[(q,r)][0] + l0*cos(5*pi/3),pos[(q,r)][1] + l0*sin(5*pi/3))
        
        G.add_edge((q,r),(q-1,r))
        pos[(q-1,r)] = (pos[(q,r)][0] + l0,pos[(q,r)][1])
        
        G.add_edge((q,r),(q-1,r+1))
        pos[(q-1,r+1)] = (pos[(q,r)][0] + l0*cos(pi/3),pos[(q,r)][1] + l0*sin(pi/3))
        
        G.add_edge((q,r),(q,r+1))
        pos[(q,r+1)] = (pos[(q,r)][0] + l0*cos(2*pi/3),pos[(q,r)][1] + l0*sin(2*pi/3))
        
        G.add_edge((q,r),(q+1,r-1))
        pos[(q+1,r-1)] = (pos[(q,r)][0] + l0*cos(4*pi/3),pos[(q,r)][1] + l0*sin(4*pi/3))
        
        G.add_edge((q,r),(q+1,r))
        pos[(q+1,r)] = (pos[(q,r)][0] - l0,pos[(q,r)][1])

remove = [node for node,degree in dict(G.degree()).items() if degree <= 2]
G.remove_nodes_from(remove)
for node in remove:
    del pos[node]

# Pratical functions for graph use

def index2tuple(pos,i):
    # Return the tuple corresponding to node index i
    return [i for i in pos.keys()][i]

def tuple2index(pos,tuple):
    # Return the index corresponding to node tuple
    return [i for i in pos.keys()].index(tuple)

# Definition of the initial condition

X = []
Y = []
for i in range(N):
    X.append(pos[index2tuple(pos,i)][0])
    Y.append(pos[index2tuple(pos,i)][1])
X = np.array(X, dtype=float)
Y = np.array(Y, dtype=float)

Displ = np.zeros([2*Nmat]) # Solid at rest

for i in range(Nmat):
    Displ[2*i] = X[i] - pos[index2tuple(pos,i)][0]
    Displ[2*i+1] = Y[i] - pos[index2tuple(pos,i)][1]
    
n = np.random.uniform(0, 2*np.pi, Nmat) # Random initial orientation

# Define the dynamical matrix

S = np.zeros([2*N,2*N])

for i in range(N):
    for neighbors in [p for p in G.neighbors(index2tuple(pos,i))]:
        j = tuple2index(pos,neighbors)
        S[2*i,2*j] = (X[i] - X[j])*(X[i] - X[j]) + (1-(1/alpha))
        S[2*i+1,2*j+1] = (Y[i] - Y[j])*(Y[i] - Y[j]) + (1-(1/alpha))
        S[2*i+1,2*j] = (Y[i] - Y[j])*(X[i] - X[j])
        S[2*i,2*j+1] = (X[i] - X[j])*(Y[i] - Y[j])
    S[2*i, 2*i] = -sum(S[2*i, 0::2])
    S[2*i+1, 2*i+1] = -sum(S[2*i+1, 1::2])
    S[2*i+1, 2*i] = -sum(S[2*i+1, 0::2])
    S[2*i, 2*i+1] = -sum(S[2*i, 1::2])
    
S = -S

S = np.delete(S, [i for i in range(2*Nmat,2*N)], axis=0)
S = np.delete(S, [i for i in range(2*Nmat,2*N)], axis=1)

eigenvalues, eigenvectors = np.linalg.eigh(S) # Normal mode spectrum

# Rescale eigenvalues to make unit long active solid
 
rescale = eigenvalues[0]
D = np.diag(eigenvalues/rescale)

P = np.zeros([2*Nmat,2*Nmat])
for i in range(2*Nmat):
    P[i,:] = eigenvectors[i]
P_1 = np.linalg.inv(P)
    
S = np.dot(np.dot(P,D),P_1)

# Functions

def elasticForce(Displ, S):
        
    Fel = -np.dot(S, Displ)
        
    return Fel

def fun(t, y):
    
    Displ = y[:2*Nmat]
    n = y[2*Nmat:]%(2*pi)
    
    Fel = elasticForce(Displ, S)
    
    rhs = np.zeros([3*Nmat])
    
    for i in range(Nmat):
    
        Fx, Fy = Fel[2*i], Fel[2*i+1]
        F = sqrt(Fx*Fx + Fy*Fy)
        theta = atan2(Fy,Fx)
    
        rhs[2*i] = (PiBar)*cos(n[i]) + F*cos(theta)
        rhs[2*i+1] = (PiBar)*sin(n[i]) + F*sin(theta)
        rhs[2*Nmat+i] = F*sin(theta - n[i])
    
    return rhs
    
# Save the csv file

def saveData(Xt, Yt, nt, i):

    fname = "result"+str(i)+".csv"
    file = open(fname, "w")

    try:
        writer = csv.writer(file, delimiter=",")

        for it in range(0,num,1):
	
            writer.writerow(Xt[it,:].tolist())
            writer.writerow(Yt[it,:].tolist())
            writer.writerow(nt[it,:].tolist())
	
    finally:
        file.close()

    return(0)

########
# Main #
########

y0 = np.concatenate([Displ,n], axis=0)
        
t_span = np.array([0, num*dt]) 
sol = solve_ivp(fun, t_span, y0, method='RK45', t_eval=np.linspace(0, num*dt, num+1))
    
Displt = np.transpose(sol.y[:2*Nmat,:])
nt = np.transpose(sol.y[2*Nmat:,:]%(2*pi))
        
print("Computation ended correctly")

saveData(Displt[:,0::2], Displt[:,1::2], nt, IND)

# Save the file of neighbors

fname = "neighbors.csv"
file = open(fname, "w")

try:
    writer = csv.writer(file, delimiter=",")

    for e in G.edges:

        i = tuple2index(pos,e[0])
        j = tuple2index(pos,e[1])
	
        writer.writerow([i,j])
	
finally:
    file.close()

